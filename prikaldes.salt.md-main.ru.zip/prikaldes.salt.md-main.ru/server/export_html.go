package server

import (
	"crypto/rand"
	"encoding/base64"
	"encoding/json"
	"html"
	"net/http"
	"net/url"
	"regexp"
	"strconv"
	"strings"
	"time"
)

// safeURL returns s only if it is a benign http(s)/mailto (or scheme-relative)
// link; anything else — notably javascript: and data: — collapses to "#" so an
// attacker-planted block URL cannot execute script in an exported document.
func safeURL(s string) string {
	u, err := url.Parse(strings.TrimSpace(s))
	if err != nil {
		return "#"
	}
	switch strings.ToLower(u.Scheme) {
	case "", "http", "https", "mailto":
		return s
	default:
		return "#"
	}
}

// safeImageURL is safeURL with one addition: a data: URI that really is an
// image. An <img> cannot execute anything, which is why the rule that keeps
// data: out of LINKS does not have to apply here.
//
// It matters because of a chain nobody would guess. A diagram is shown as an
// image with its drawing in a data: URI — so copying one and pasting it
// somewhere else stores an image block holding that URI. safeURL turned it into
// "#" and the picture vanished from the PDF, silently, while the page on screen
// showed it perfectly well. Anything else pasted as a data: image was going the
// same way.
//
// Only image types, and no SVG: an SVG in an <img> cannot run script, but the
// prefix check is cheap and the list of things that are certainly harmless is
// short. SVG is allowed because that is what a diagram IS, and it goes through
// sanitizeSVG on the way in.
func safeImageURL(s string) string {
	t := strings.TrimSpace(s)
	if strings.HasPrefix(strings.ToLower(t), "data:image/") && strings.Contains(t, ",") {
		return t
	}
	return safeURL(s)
}

// BlockNote JSON → self-contained HTML. Used by the export endpoint's ?format=html
// so a page can be opened in a browser or imported elsewhere with real structure
// (headings, lists, tables) rather than only Markdown.

func inlineHTML(raw json.RawMessage) string {
	var items []mdInline
	if len(raw) == 0 || json.Unmarshal(raw, &items) != nil {
		return ""
	}
	var b strings.Builder
	for _, it := range items {
		switch it.Type {
		case "link":
			// Through safeURL like every other address on the page. A link typed
			// as javascript:… went out as it was, and one click ran it with the
			// session of whoever opened the print view or the shared page.
			b.WriteString(`<a href="` + html.EscapeString(safeURL(it.Href)) + `">` + inlineHTML(it.Content) + "</a>")
		case "pageLink":
			label := strProp(it.Props, "label", "Untitled")
			id := strProp(it.Props, "pageId", "")
			b.WriteString(`<a href="/p/` + html.EscapeString(id) + `">` + html.EscapeString(label) + "</a>")
		default:
			t := html.EscapeString(it.Text)
			if t == "" {
				continue
			}
			if truthy(it.Styles["code"]) {
				b.WriteString("<code>" + t + "</code>")
				continue
			}
			if truthy(it.Styles["bold"]) {
				t = "<strong>" + t + "</strong>"
			}
			if truthy(it.Styles["italic"]) {
				t = "<em>" + t + "</em>"
			}
			if truthy(it.Styles["strike"]) {
				t = "<s>" + t + "</s>"
			}
			if truthy(it.Styles["underline"]) {
				t = "<u>" + t + "</u>"
			}
			b.WriteString(t)
		}
	}
	return b.String()
}

func blocksToHTML(content []byte) string {
	var blocks []mdBlock
	if json.Unmarshal(content, &blocks) != nil {
		return ""
	}
	var b strings.Builder
	renderBlocksHTML(&b, blocks)
	return b.String()
}

// renderBlocksHTML walks a block list, grouping consecutive list items of the
// same kind into a single <ul>/<ol>.
func renderBlocksHTML(b *strings.Builder, blocks []mdBlock) {
	i := 0
	for i < len(blocks) {
		blk := blocks[i]
		switch {
		case blk.Type == "bulletListItem" || blk.Type == "checkListItem":
			j := i
			b.WriteString("<ul>")
			for j < len(blocks) && (blocks[j].Type == "bulletListItem" || blocks[j].Type == "checkListItem") {
				renderListItemHTML(b, blocks[j])
				j++
			}
			b.WriteString("</ul>")
			i = j
		case blk.Type == "numberedListItem":
			j := i
			b.WriteString("<ol>")
			for j < len(blocks) && blocks[j].Type == "numberedListItem" {
				renderListItemHTML(b, blocks[j])
				j++
			}
			b.WriteString("</ol>")
			i = j
		default:
			renderBlockHTML(b, blk)
			i++
		}
	}
}

func renderListItemHTML(b *strings.Builder, blk mdBlock) {
	b.WriteString("<li>")
	if blk.Type == "checkListItem" {
		if truthy(blk.Props["checked"]) {
			b.WriteString(`<input type="checkbox" checked disabled> `)
		} else {
			b.WriteString(`<input type="checkbox" disabled> `)
		}
	}
	b.WriteString(inlineHTML(blk.Content))
	if len(blk.Children) > 0 {
		renderBlocksHTML(b, blk.Children)
	}
	b.WriteString("</li>")
}

func renderBlockHTML(b *strings.Builder, blk mdBlock) {
	switch blk.Type {
	case "heading":
		level := intProp(blk.Props, "level", 1)
		if level < 1 || level > 6 {
			level = 1
		}
		tag := "h" + string(rune('0'+level))
		b.WriteString("<" + tag + ">" + inlineHTML(blk.Content) + "</" + tag + ">")
	case "quote":
		b.WriteString("<blockquote>" + inlineHTML(blk.Content) + "</blockquote>")
	case "codeBlock":
		b.WriteString("<pre><code>" + html.EscapeString(plainInline(blk.Content)) + "</code></pre>")
	case "divider":
		b.WriteString("<hr>")
	case "image":
		b.WriteString(`<img src="` + html.EscapeString(safeImageURL(strProp(blk.Props, "url", ""))) + `" alt="` + html.EscapeString(strProp(blk.Props, "name", "")) + `">`)
	case "video", "audio", "file":
		link := html.EscapeString(safeURL(strProp(blk.Props, "url", "")))
		b.WriteString(`<p><a href="` + link + `">` + html.EscapeString(strProp(blk.Props, "name", blk.Type)) + "</a></p>")
	case "toggleListItem":
		b.WriteString("<details><summary>" + inlineHTML(blk.Content) + "</summary>")
		if len(blk.Children) > 0 {
			renderBlocksHTML(b, blk.Children)
		}
		b.WriteString("</details>")
		return
	case "callout":
		emoji := html.EscapeString(strProp(blk.Props, "emoji", "💡"))
		b.WriteString(`<div style="display:flex;gap:10px;background:rgba(47,125,79,.1);border-radius:10px;padding:12px 14px"><span>` + emoji + "</span><div>" + inlineHTML(blk.Content) + "</div></div>")
	case "bookmark":
		if raw := strProp(blk.Props, "url", ""); raw != "" {
			link := html.EscapeString(safeURL(raw))
			b.WriteString(`<p><a href="` + link + `">🔖 ` + html.EscapeString(raw) + "</a></p>")
		}
	case "database":
		// Only the reference, as in the Markdown export — the rows live in the
		// database page and a copy of them would go stale immediately.
		if id := strProp(blk.Props, "collectionId", ""); id != "" {
			b.WriteString(`<p><a href="/p/` + html.EscapeString(id) + `">▦ Collection</a></p>`)
		}
	case "toc":
		// Generated client-side; skip in export.
	case "subpages":
		// Generated client-side from the page tree; skip in export.
	// columnList is the OLD shape, from the paid package that used to provide
	// columns: an outer block whose children are column blocks, each with its
	// own children. Nothing writes it any more, and it stays because a page
	// written before the change must not lose its layout.
	case "columnList":
		b.WriteString(`<div class="cols">`)
		for _, col := range blk.Children {
			b.WriteString(`<div>`)
			renderBlocksHTML(b, col.Children)
			b.WriteString("</div>")
		}
		b.WriteString("</div>")
		return
	// columns is ours: the block holds nothing, and its CHILDREN are the
	// columns — one block each. Same shape the editor lays out, so what is on
	// screen is what comes out of the printer.
	case "columns":
		n := 2
		if v, ok := blk.Props["count"]; ok {
			if f, ok := v.(float64); ok && int(f) == 3 {
				n = 3
			}
		}
		b.WriteString(`<div class="cols" data-count="` + strconv.Itoa(n) + `">`)
		for _, col := range blk.Children {
			b.WriteString(`<div>`)
			renderBlocksHTML(b, []mdBlock{col})
			b.WriteString("</div>")
		}
		b.WriteString("</div>")
		return
	// A diagram carries its own picture: the editor draws it and stores the SVG
	// back on the block. That is what lets it appear here at all — this runs on
	// the SERVER, which has no way to draw one.
	//
	// Without a picture the SOURCE is printed instead of nothing. A page an
	// agent wrote and nobody has opened yet has no SVG, and "A --> B" on the
	// page is worth more than a gap where a diagram should be.
	case "mermaid":
		svg, _ := blk.Props["svg"].(string)
		// sanitizeSVG returning empty is a REFUSAL, not an empty picture, so it
		// falls through to the source below. Writing the empty result into the
		// page put a blank box where a diagram belonged and said nothing about
		// why — which is how the foreignObject refusal stayed invisible.
		if clean := sanitizeSVG(svg); strings.Contains(clean, "<svg") {
			// The same rule the editor follows: the drawing's own size, shrunk
			// to fit a narrower page, never blown up. The width and height were
			// stripped when it was drawn so that CSS could decide, which means
			// something has to say what the size IS — and on paper "as wide as
			// the page" turns a small flowchart into a full sheet.
			//
			// And as a picture, never as markup. Written into the page, the
			// stored SVG was part of the document, so any event handler the
			// sanitizer's list did not know (onbegin on an animation got
			// through) ran with the session of whoever opened the print view
			// or the shared link. An <img> runs no script at all, which is
			// also how the editor shows a diagram.
			code, _ := blk.Props["code"].(string)
			b.WriteString(`<div class="diagram"` + diagramStyle(clean) + `><img alt="` + html.EscapeString(strings.TrimSpace(code)) +
				`" src="data:image/svg+xml;base64,` + base64.StdEncoding.EncodeToString([]byte(clean)) + `"></div>`)
			return
		}
		if code, _ := blk.Props["code"].(string); strings.TrimSpace(code) != "" {
			b.WriteString("<pre><code>" + html.EscapeString(code) + "</code></pre>")
		}
		return
	case "table":
		renderTableHTML(b, blk.Content)
	default: // paragraph & unknown
		if t := inlineHTML(blk.Content); t != "" {
			b.WriteString("<p>" + t + "</p>")
		}
	}
	if len(blk.Children) > 0 {
		renderBlocksHTML(b, blk.Children)
	}
}

func renderTableHTML(b *strings.Builder, raw json.RawMessage) {
	var tc struct {
		Rows []struct {
			Cells []json.RawMessage `json:"cells"`
		} `json:"rows"`
	}
	if json.Unmarshal(raw, &tc) != nil || len(tc.Rows) == 0 {
		return
	}
	renderCell := func(c json.RawMessage) string {
		var obj struct {
			Content json.RawMessage `json:"content"`
		}
		if err := json.Unmarshal(c, &obj); err == nil && len(obj.Content) > 0 {
			return inlineHTML(obj.Content)
		}
		return inlineHTML(c)
	}
	b.WriteString("<table>")
	for _, row := range tc.Rows {
		b.WriteString("<tr>")
		for _, c := range row.Cells {
			b.WriteString("<td>" + renderCell(c) + "</td>")
		}
		b.WriteString("</tr>")
	}
	b.WriteString("</table>")
}

// printOptions is the house style for a printed document: what appears besides
// the text itself. Everything here is off-by-default-safe — an option nobody
// touches produces the plain document people expected before any of this
// existed.
type printOptions struct {
	Cover     bool // a title page of its own
	Icon      bool // the document's emoji beside its title
	Footer    bool // title and date at the foot of every page
	Workspace bool // which workspace and instance this came from
	PageNums  bool // page numbers, counted by us
	Comments  bool // the page's comments, after the document
	Links     bool // links as links, rather than flattened to plain text
	Landscape bool // the sheet turned, for documents made of wide tables

	WSName   string
	Instance string
	Date     string
	Region   string
	Language string
	CommentL []commentJSON
	// Nonce is the one script the document may run (see docCSP). Empty for a
	// file that is downloaded: no header travels with it.
	Nonce string
}

// printOptionsFor reads the instance's defaults. They are settings rather than
// per-export choices because they describe how documents from THIS instance
// look — a house style, not a decision somebody makes forty times. The bar
// beside a print view can still deviate for one document.
func (s *Server) printOptionsFor(p *page) printOptions {
	o := printOptions{
		Cover:     s.boolSetting("pdf_cover"),
		Icon:      s.setting("pdf_icon", "1") == "1",
		Footer:    s.setting("pdf_footer", "1") == "1",
		Workspace: s.setting("pdf_workspace", "1") == "1",
		PageNums:  s.setting("pdf_pagenums", "1") == "1",
		Comments:  s.boolSetting("pdf_comments"),
		Links:     s.setting("pdf_links", "1") == "1",
		Landscape: s.boolSetting("pdf_landscape"),
		Instance:  s.setting("instance_name", ""),
		Date:      time.Now().UTC().Format("2006-01-02"),
	}
	if p.WorkspaceID != "" {
		s.db.QueryRow(`SELECT name FROM workspaces WHERE id = ?`, p.WorkspaceID).Scan(&o.WSName)
	}
	// Fetched whatever the default says, because the bar can switch comments on
	// without going back to the server — and a toggle that needs a round trip
	// reopens the print dialog, which is the thing being fixed here.
	if list, err := s.pageComments(p.ID); err == nil {
		o.CommentL = list
	}
	return o
}

// classList turns the options into classes on <body>. Every one of them is a
// pure display choice, which is what lets the bar beside the document flip them
// live: no reload, so no print dialog springing open on every click.
func (o printOptions) classList() string {
	on := func(b bool, name string) string {
		if b {
			return " " + name
		}
		return ""
	}
	return "doc" +
		on(o.Cover, "opt-cover") + on(o.Icon, "opt-icon") + on(o.Footer, "opt-foot") +
		on(o.Workspace, "opt-ws") + on(o.PageNums, "opt-nums") +
		on(o.Comments, "opt-comments") + on(o.Links, "opt-links") +
		on(o.Landscape, "opt-landscape")
}

const htmlDocStyle = `*{box-sizing:border-box}
body{margin:0;font:16px/1.65 -apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;color:#1f1f1d;background:#f0efec;-webkit-print-color-adjust:exact;print-color-adjust:exact}
h1{font-size:2.1em;line-height:1.2;margin:0 0 .1em;font-weight:700}
h2{font-size:1.5em;line-height:1.25;margin:1.5em 0 .4em}
h3{font-size:1.2em;margin:1.2em 0 .3em}
p{margin:.55em 0}
.doc-desc{font-size:1.05em;color:#5b5b57;margin:.15em 0 1.7em}
img{max-width:100%;height:auto;border-radius:6px}
pre{background:#f5f5f4;padding:14px 16px;border-radius:8px;overflow-x:auto}
code{background:#f5f5f4;padding:1px 5px;border-radius:4px;font-size:.9em}
pre code{background:none;padding:0}
blockquote{border-left:3px solid #e3e2df;margin:1em 0;padding:.2em 0 .2em 16px;color:#5b5b57}
table{border-collapse:collapse;width:100%;margin:1em 0}
/* break-word, deliberately NOT anywhere. The latter also lets the browser
   squeeze every column to its narrowest possible width, and a seven-column
   table then came out reading "erlaub / en" and "192.0.2.3 / 8" — it fitted the
   paper and nobody could read it. This breaks only a word that would not fit on
   a line by itself; a table still too wide is scaled down whole by the script,
   which keeps every column in proportion. */
td,th{border:1px solid #e3e2df;padding:7px 11px;text-align:left;overflow-wrap:break-word}
hr{border:none;border-top:1px solid #e3e2df;margin:2em 0}
ul,ol{padding-left:1.4em}li{margin:.25em 0}
a{color:#2f6fb0}
body:not(.opt-links) a{color:inherit;text-decoration:none}
body:not(.opt-icon) .doc-icon{display:none}
/* All three kinds sit on the text baseline at the size of the heading they
   belong to, so a document with an emoji and one with a drawn icon look like
   the same document. */
.doc-icon-svg,.doc-icon-img{display:inline-block;width:1em;height:1em;vertical-align:-0.12em}
.doc-icon-img{border-radius:.15em;object-fit:contain}
body:not(.opt-comments) .doc-comments{display:none}
body:not(.opt-ws) .cover-ws{display:none}
.cols{display:grid;gap:24px;align-items:start;grid-template-columns:repeat(2,minmax(0,1fr))}
.cols[data-count="3"]{grid-template-columns:repeat(3,minmax(0,1fr))}
.cols>div>*:first-child{margin-top:0}
.diagram{margin:1em 0}
.diagram img{width:100%;height:auto;display:block}
.doc-comments{margin-top:2.2em;border-top:1px solid #e3e2df;padding-top:1em}
.doc-comments h2{font-size:1.2em;margin:0 0 .6em}
.doc-comment{margin:0 0 .8em;font-size:.95em}
.doc-comment .who{font-weight:600}
.doc-comment .when{color:#8a8a85;font-size:.85em;margin-left:.4em}

/* A sheet is a real sheet of paper: fixed size, its own margins, its own foot.
   The document is cut into these by the script below rather than left to the
   browser, and that is what makes a page NUMBER possible at all. Nothing in a
   web page can count printed pages — the CSS feature meant for it exists on
   paper and no browser implements it. Cutting the pages ourselves means we
   already know how many there are, and which one we are on. */
/* 296mm, not 297. A box exactly as tall as the paper plus a forced break after
   it lands the break at the very start of the next sheet, and the browser then
   advances one MORE — every sheet came out followed by a blank one. One
   millimetre of slack is the whole fix.
 
   And no overflow:hidden. A block taller than any sheet has to run on and be
   ugly; clipping it would lose the end of a document silently, which is the one
   failure nobody would notice until a customer did. */
.sheet{width:210mm;height:296mm;padding:16mm 15mm 20mm;position:relative;background:#fff}
.sheet-body{height:260mm}
/* Landscape is the same sheet turned, and the @page rule is turned with it by
   the script — an at-rule cannot be scoped to a class, so it is the one thing
   here that is written rather than switched. */
body.opt-landscape .sheet{width:297mm;height:209mm}
body.opt-landscape .sheet-body{height:173mm}
.sheet-foot{position:absolute;left:15mm;right:15mm;bottom:10mm;display:flex;justify-content:space-between;gap:12px;font-size:8.5pt;color:#8a8a85;border-top:1px solid #e3e2df;padding-top:2.5mm}
body:not(.opt-foot) .foot-title{visibility:hidden}
body:not(.opt-nums) .foot-num{visibility:hidden}
/* A title page carries no number and no running foot. Nobody numbers a cover. */
.sheet-cover .sheet-foot{display:none}
.sheet-cover .sheet-body{display:flex;flex-direction:column;justify-content:center}
.sheet-cover h1{font-size:2.6em;margin:0 0 .3em}
.cover-rule{width:56px;border-top:3px solid #2f7d4f;margin:0 0 1.4em}
.cover-meta{font-size:1em;color:#5b5b57;line-height:1.9}

/* On screen the sheets lie on a desk, so what you see is what comes out. */
@media screen{
.sheets{padding:26px 0 44px}
.sheet{margin:0 auto 20px;box-shadow:0 1px 3px rgba(0,0,0,.12),0 8px 24px rgba(0,0,0,.08);border-radius:2px}
.doc-side{position:fixed;top:20px;right:20px;width:252px;background:#fff;border:1px solid #e3e2df;border-radius:12px;padding:14px 16px;box-shadow:0 6px 20px rgba(0,0,0,.1);font-size:14px;z-index:10}
.doc-side h3{margin:0 0 8px;font-size:12px;text-transform:uppercase;letter-spacing:.05em;color:#8a8a85;font-weight:600}
.doc-side label{display:flex;gap:9px;align-items:flex-start;padding:5px 0;cursor:pointer;line-height:1.35}
.doc-side input{margin-top:3px}
.doc-side .go{width:100%;margin-top:12px;font:inherit;font-weight:600;cursor:pointer;background:#2f7d4f;color:#fff;border:none;border-radius:8px;padding:9px 14px}
.doc-side .dep-cover{opacity:.4}
body.opt-cover .doc-side .dep-cover{opacity:1}
.doc-side .note{margin:9px 0 0;font-size:12px;color:#8a8a85;line-height:1.45}
@media (max-width:1180px){.doc-side{position:static;width:auto;margin:16px auto 0;max-width:210mm;box-shadow:none}}
}

/* Printing. @page has NO margin, because Chrome draws its own header and footer
   INTO the margin — date and title above, address and page number below — and a
   page cannot switch that off. With no margin there is nowhere for them to go,
   and every margin you see is the sheet's own padding instead. */
@media print{
@page{margin:0;size:A4}
html,body{background:#fff}
.doc-side{display:none!important}
.sheets{padding:0}
.sheet{margin:0;box-shadow:none;border-radius:0;break-after:page;page-break-after:always}
.sheet:last-child{break-after:auto;page-break-after:auto}
a{color:#1a1a1a}
}`

// pageHTML renders a document page as a full standalone HTML document.
//
// In print mode it does NOT hand the document to the browser and hope. It hands
// over finished sheets: the script cuts the flow into A4 pages, and the browser
// only puts them on paper. That is what a page number needs — and the reason
// the print dialog no longer springs open on load, because every option is now
// a class on <body> and changes nothing that needs the server.
func (srv *Server) pageHTML(p *page, printMode bool, o printOptions) string {
	title := p.Title
	if title == "" {
		title = "Untitled"
	}
	esc := html.EscapeString
	icon := ""
	if h := srv.iconHTML(p.Icon); h != "" {
		icon = h + " "
	}

	var b strings.Builder
	b.WriteString(`<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>`)
	b.WriteString(esc(title))
	b.WriteString("</title><style>" + htmlDocStyle + "</style></head>")
	b.WriteString(`<body class="` + o.classList() + `">`)

	if printMode {
		b.WriteString(sidePanelHTML())
	}

	// The document, as one flow. The script takes it from here; without the
	// script (or before it runs) this is still the whole document, readable and
	// printable — just with the browser choosing where the pages fall.
	b.WriteString(`<template id="doc-src">`)
	b.WriteString("<h1>" + icon + esc(title) + "</h1>")
	if d := strings.TrimSpace(p.Description); d != "" {
		b.WriteString(`<p class="doc-desc">` + esc(d) + "</p>")
	}
	b.WriteString(blocksToHTML(p.Content))
	if len(o.CommentL) > 0 {
		b.WriteString(`<section class="doc-comments"><h2>Comments</h2>`)
		for _, c := range o.CommentL {
			b.WriteString(`<p class="doc-comment"><span class="who">` + esc(c.AuthorName) + `</span>`)
			if len(c.CreatedAt) >= 10 {
				b.WriteString(`<span class="when">` + esc(c.CreatedAt[:10]) + `</span>`)
			}
			b.WriteString("<br>" + esc(c.Body) + "</p>")
		}
		b.WriteString("</section>")
	}
	b.WriteString(`</template>`)

	// The cover, kept apart so paginating never has to reason about it.
	b.WriteString(`<template id="doc-cover"><div class="cover-rule"></div><h1>` + icon + esc(title) + "</h1>")
	if d := strings.TrimSpace(p.Description); d != "" {
		b.WriteString(`<p class="doc-desc">` + esc(d) + "</p>")
	}
	// Both parts are always rendered and hidden by class, never left out here.
	// Rendered conditionally, the panel beside the document could not switch
	// them back on without asking the server — and that round trip is exactly
	// what reopens the print dialog on every click.
	b.WriteString(`<div class="cover-meta"><span class="cover-ws">`)
	for _, line := range originLines(o) {
		b.WriteString(esc(line) + "<br>")
	}
	b.WriteString(`</span><span class="cover-day"></span></div></template>`)

	b.WriteString(`<div class="sheets" id="sheets"></div>`)
	// The date travels as a plain calendar day and is written out in the
	// browser, in the reader's own regional format — the same rule the rest of
	// the product follows. Formatting it here would have shipped one spelling to
	// everybody, and it would have been ISO, which no reader writes by hand.
	nonce := ""
	if o.Nonce != "" {
		nonce = ` nonce="` + o.Nonce + `"`
	}
	b.WriteString(`<script` + nonce + `>` + paginateJS + "\n" +
		`SALT_TITLE=` + jsString(title) + `;` +
		`SALT_DAY=` + jsString(o.Date) + `;` +
		`SALT_REGION=` + jsString(o.Region) + `;` +
		`SALT_LANG=` + jsString(o.Language) + `;` +
		`saltStart();` +
		`document.querySelectorAll('[data-print]').forEach(function(b){b.addEventListener('click',function(){window.print()})});` +
		`</script>`)
	b.WriteString("</body></html>")
	return b.String()
}

func jsString(v string) string {
	out, _ := json.Marshal(v)
	return string(out)
}

// originLines is where the document came from — the workspace and the instance,
// which is the part the "Workspace and instance" switch hides. The date is not
// in here: it belongs to the document, not to the place it lives, and it stays
// on the title page either way.
//
// Empty entries are dropped rather than printed as blank lines, so an instance
// that has set no name simply shows one line fewer.
func originLines(o printOptions) []string {
	out := []string{}
	if o.WSName != "" {
		out = append(out, o.WSName)
	}
	if o.Instance != "" && o.Instance != o.WSName {
		out = append(out, o.Instance)
	}
	return out
}

// sidePanelHTML is the strip of choices beside the document, on screen only.
// Beside and not above: it stays put while you scroll through the sheets, and
// the document underneath keeps the exact width it will have on paper.
func sidePanelHTML() string {
	box := func(cls, label string) string {
		return `<label><input type="checkbox" data-cls="` + cls + `"> ` + html.EscapeString(label) + `</label>`
	}
	return `<aside class="doc-side"><h3>Page setup</h3>` +
		box("opt-cover", "Title page") +
		box("opt-icon", "Icon") +
		box("opt-foot", "Title and date at the foot") +
		box("opt-nums", "Page numbers") +
		// Only the title page has room for it, so with no title page the switch
		// does nothing — and a switch that does nothing without saying why is
		// the thing people report as broken. It dims instead.
		`<label class="dep-cover" title="Shown on the title page"><input type="checkbox" data-cls="opt-ws"> Workspace and instance</label>` +
		box("opt-comments", "Comments") +
		box("opt-links", "Links as links") +
		box("opt-landscape", "Landscape") +
		`<button class="go" data-print>Print / Save as PDF</button>` +
		`<p class="note">What you see is what comes out. Nothing is sent anywhere.</p></aside>`
}

// applyPrintQuery lets a link or a bookmark deviate
// from the instance's house style. Absent parameters keep the default: this is
// an override, not a form, so an old link keeps meaning what it meant.
func applyPrintQuery(o printOptions, q url.Values) printOptions {
	set := func(name string, target *bool) {
		switch q.Get(name) {
		case "1":
			*target = true
		case "0":
			*target = false
		}
	}
	set("cover", &o.Cover)
	set("icon", &o.Icon)
	set("foot", &o.Footer)
	set("ws", &o.Workspace)
	set("nums", &o.PageNums)
	set("comments", &o.Comments)
	set("links", &o.Links)
	set("landscape", &o.Landscape)
	return o
}

// paginateJS cuts the document into sheets, and it is the piece that makes a
// page number possible: a browser will not tell a page how many sheets it will
// use, so the page decides instead. Every sheet is an explicit box of exactly
// one A4, forced to break after itself, which leaves the browser nothing to
// disagree about.
//
// The measurement is honest rather than clever: put a block on the sheet, ask
// whether the sheet now overflows, and if it does move it to the next one. A
// table too tall for any sheet is cut between its ROWS, because a table is what
// most documents that get printed are made of and the alternative is a page and
// a half of white space.
const paginateJS = `
var SALT_TITLE='',SALT_DAY='',SALT_REGION='',SALT_LANG='';

// saltLocale is the same rule i18n.ts follows: the account's region wins, and
// with none, the browser tag whose base matches the interface language — so a
// German interface in an English browser still writes 10.08.2026 rather than
// 08/10/2026. Falling back to the browser's own default instead was wrong in
// exactly that case, which is the common one for anybody who keeps their
// browser in English.
function saltLocale(){
  if(SALT_REGION)return SALT_REGION;
  var tags=navigator.languages||[navigator.language||''];
  if(SALT_LANG){
    for(var i=0;i<tags.length;i++)if(tags[i].split('-')[0]===SALT_LANG)return tags[i];
    return SALT_LANG;
  }
  return tags[0]||undefined;
}

// saltDay writes a calendar day out the way the reader writes one. Same rule as
// format.ts, and the same trap avoided: new Date('2026-08-10') is UTC midnight,
// which renders as the 9th west of Greenwich. Built from the parts instead, so
// the day asked for is the day shown, everywhere on earth.
function saltDay(iso){
  if(!iso)return '';
  var m=/^(\d{4})-(\d{2})-(\d{2})$/.exec(iso);
  if(!m)return iso;
  var d=new Date(+m[1],+m[2]-1,+m[3]);
  try{
    return new Intl.DateTimeFormat(saltLocale()||undefined,
      {year:'numeric',month:'2-digit',day:'2-digit'}).format(d);
  }catch(e){return iso;}
}

// The page box has to agree with the sheet, or the browser scales or splits it.
// @page cannot be scoped to a class, so it is rewritten instead of switched.
function saltPageRule(){
  var st=document.getElementById('salt-page');
  if(!st){st=document.createElement('style');st.id='salt-page';document.head.appendChild(st);}
  st.textContent='@page{size:A4 '+(document.body.classList.contains('opt-landscape')?'landscape':'portrait')+';margin:0}';
}

// The last resort for a table that is still too wide once words may break: shrink
// it to fit. Ugly, and far better than a column disappearing off the paper where
// nobody sees that it is missing.
function saltFitWide(body){
  var t=body.querySelectorAll('table');
  for(var i=0;i<t.length;i++){
    var el=t[i],box=el.getBoundingClientRect(),w=box.width,h=box.height;
    if(w<=body.clientWidth+1)continue;
    var f=body.clientWidth/w;
    // Both measurements are taken BEFORE the transform. getBoundingClientRect
    // reports the TRANSFORMED box, so reading the height afterwards and scaling
    // it again made the wrapper too short and cut the last row off the table.
    el.style.transformOrigin='left top';
    el.style.transform='scale('+f.toFixed(4)+')';
    // A transformed element still claims its old height in the flow, which
    // would leave a gap and mis-measure the sheet. A wrapper carries the real
    // one — and does not hide the overflow, so a mistake here shows up as
    // something overlapping rather than as content quietly missing.
    var wrap=document.createElement('div');
    wrap.style.height=(h*f)+'px';
    el.parentNode.insertBefore(wrap,el);
    wrap.appendChild(el);
  }
}

// Cut the pages again once every picture has a height.
//
// An image has NO size until it is loaded, and the sheets are measured by
// height — so a page full of pictures measured as if they were nothing, decided
// everything fit on one sheet, and then spilled off the bottom of the paper the
// moment they appeared. It said 1 / 1 while running over two pages.
//
// Two passes rather than waiting first: the images only start loading once they
// are in the document, and inside a <template> they never load at all.
function saltAfterImages(cb){
  var imgs=document.querySelectorAll('#sheets img');
  var left=0,done=false;
  function fin(){if(done)return;done=true;cb();}
  function tick(){if(--left<=0)fin();}
  for(var i=0;i<imgs.length;i++){
    var im=imgs[i];
    if(im.complete&&im.naturalWidth)continue;
    left++;
    im.addEventListener('load',tick);
    im.addEventListener('error',tick);
  }
  if(left===0){fin();return;}
  // A picture that never loads must not leave the document uncut.
  setTimeout(fin,4000);
}

function saltStart(){
  var day=saltDay(SALT_DAY);
  SALT_FOOT=day?SALT_TITLE+' \u00b7 '+day:SALT_TITLE;
  var c=document.querySelector('#doc-cover');
  if(c){
    var slot=c.content.querySelector('.cover-day');
    if(slot)slot.textContent=day;
  }
  saltRepaginate();
}

// Cut, then cut again once the pictures have loaded and therefore have a size.
function saltRepaginate(){
  saltPaginate();
  saltAfterImages(saltPaginate);
}
var SALT_FOOT='';
function saltPaginate(){
  saltPageRule();
  var src=document.getElementById('doc-src'),cov=document.getElementById('doc-cover');
  var host=document.getElementById('sheets');
  if(!src||!host)return;
  host.textContent='';
  var body=document.body,withCover=body.classList.contains('opt-cover');

  function sheet(cls){
    var s=document.createElement('section');
    s.className='sheet'+(cls?' '+cls:'');
    var b=document.createElement('div');b.className='sheet-body';s.appendChild(b);
    var f=document.createElement('div');f.className='sheet-foot';
    f.innerHTML='<span class="foot-title"></span><span class="foot-num"></span>';
    f.firstChild.textContent=SALT_FOOT;
    s.appendChild(f);host.appendChild(s);return b;
  }
  function over(b){return b.scrollHeight>b.clientHeight+1;}

  if(withCover){
    var cb=sheet('sheet-cover');
    cb.appendChild(cov.content.cloneNode(true));
  }

  var cur=sheet(''),flow=src.content.cloneNode(true);
  var items=[].slice.call(flow.children);
  for(var i=0;i<items.length;i++){
    var el=items[i];
    cur.appendChild(el);
    if(!over(cur))continue;
    // It does not fit. If the sheet already held something, the block starts a
    // fresh one; if it was alone, the block is simply taller than any sheet.
    if(cur.children.length>1){
      cur.removeChild(el);
      // A heading directly above takes the move with it. A section title alone
      // at the foot of a sheet, with its table overleaf, reads like a mistake —
      // and it is the commonest thing a document made of tables does.
      var prev=cur.lastElementChild,carry=null;
      if(prev&&/^H[1-4]$/.test(prev.tagName)&&cur.children.length>1){
        carry=prev;cur.removeChild(prev);
      }
      cur=sheet('');
      if(carry)cur.appendChild(carry);
      cur.appendChild(el);
      if(!over(cur))continue;
    }
    if(el.tagName==='TABLE'){
      var rest=el;
      while(over(cur)){
        var moved=saltCutTable(rest,cur);
        if(!moved)break;
        cur=sheet('');
        cur.appendChild(moved);
        rest=moved;
      }
    }
    // Anything else that is taller than a sheet stays where it is and runs on.
    // Forcing it would only hide the end of it.
  }
  var bodies=document.querySelectorAll('.sheet:not(.sheet-cover) .sheet-body');
  for(var b=0;b<bodies.length;b++)saltFitWide(bodies[b]);
  saltNumber();
}

// saltCutTable moves rows off the end of a table until it fits, and returns the
// clone that carries them. The head row goes along, so a table continued on the
// next sheet still says what its columns are.
function saltCutTable(tbl,body){
  var rows=tbl.querySelectorAll('tr');
  if(rows.length<2)return null;
  var moved=[];
  while(body.scrollHeight>body.clientHeight+1){
    rows=tbl.querySelectorAll('tr');
    if(rows.length<2)break;
    var last=rows[rows.length-1];
    last.parentNode.removeChild(last);
    moved.unshift(last);
  }
  if(!moved.length)return null;
  var clone=tbl.cloneNode(false);
  var tb=document.createElement('tbody');
  for(var i=0;i<moved.length;i++)tb.appendChild(moved[i]);
  clone.appendChild(tb);
  return clone;
}

// The cover is not page one. Nobody numbers a title page, and starting the
// count after it is what makes "2 / 5" mean the second page of the document.
function saltNumber(){
  var sheets=[].slice.call(document.querySelectorAll('.sheet:not(.sheet-cover)'));
  for(var i=0;i<sheets.length;i++){
    var n=sheets[i].querySelector('.foot-num');
    if(n)n.textContent=(i+1)+' / '+sheets.length;
  }
}

document.addEventListener('change',function(e){
  var t=e.target;
  if(!t||!t.dataset||!t.dataset.cls)return;
  document.body.classList.toggle(t.dataset.cls,t.checked);
  saltRepaginate();
});
document.addEventListener('DOMContentLoaded',function(){
  document.querySelectorAll('.doc-side input[data-cls]').forEach(function(c){
    c.checked=document.body.classList.contains(c.dataset.cls);
  });
});
`

// iconHTML draws a page icon in an exported document. A page icon is one of
// four things in a single string, and until this existed the export printed
// whichever one it was as TEXT — so a document came off the printer with
// "lucide:Rocket" or "/files/8c94….svg" where its icon belonged. Only emoji
// happened to work, because an emoji IS its own text.
//
//	emoji            "🚀"                     text, sized by CSS
//	Lucide           "lucide:Rocket[:#hex]"   inlined from the generated set
//	MDI              "mdi:Rocket[:#hex]"      nothing — see below
//	uploaded image   "/files/abc.png"         an <img>
//
// MDI is left out on purpose rather than guessed at: the app loads those paths
// from a lazy browser chunk that the server has no copy of. Nothing is better
// than the wrong glyph, and better than the literal word "mdi:Rocket".
func (s *Server) iconHTML(icon string) string {
	icon = strings.TrimSpace(icon)
	if icon == "" {
		return ""
	}
	if strings.HasPrefix(icon, "/") || strings.HasPrefix(icon, "http") || strings.HasPrefix(icon, "data:") {
		return `<img class="doc-icon doc-icon-img" src="` + html.EscapeString(icon) + `" alt="">`
	}
	if strings.HasPrefix(icon, "lucide:") {
		name, colour := iconRef(icon)
		inner, ok := s.lucide[name]
		if !ok {
			return ""
		}
		if colour == "" {
			colour = "currentColor"
		}
		// The generated markup is ours, from a fixed set, so it goes in as it
		// is. The COLOUR comes from the page and is checked before it is used.
		return `<svg class="doc-icon doc-icon-svg" viewBox="0 0 24 24" fill="none" stroke="` +
			html.EscapeString(colour) + `" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">` +
			inner + `</svg>`
	}
	if strings.HasPrefix(icon, "mdi:") {
		return ""
	}
	return `<span class="doc-icon">` + html.EscapeString(icon) + `</span>`
}

// iconRef splits "lucide:Rocket:#e03131" into its name and colour. A trailing
// ":fill" from the old filled variants is ignored, exactly as the app ignores
// it, so an icon picked back then still resolves instead of vanishing.
//
// The colour is only accepted as a plain hex value. It reaches a stroke
// attribute, and a value from a page is not something to hand to a stylesheet
// unchecked.
func iconRef(ref string) (name, colour string) {
	parts := strings.Split(ref, ":")
	if len(parts) > 1 {
		name = parts[1]
	}
	if len(parts) > 2 && parts[2] != "fill" && hexColour(parts[2]) {
		colour = parts[2]
	}
	return name, colour
}

func hexColour(v string) bool {
	if len(v) != 4 && len(v) != 7 || v[0] != '#' {
		return false
	}
	for _, c := range v[1:] {
		if !(c >= '0' && c <= '9' || c >= 'a' && c <= 'f' || c >= 'A' && c <= 'F') {
			return false
		}
	}
	return true
}

// sanitizeSVG strips what must never travel in a stored picture: scripts, event
// handlers and foreignObject.
//
// The SVG comes from the browser that rendered the diagram, so it arrives the
// same way any page content does — from a person, possibly from an agent, and
// it is written straight into a page that other people open. Mermaid renders
// with securityLevel 'strict', which is the first line; this is the second,
// because the value in the block is only ever as trustworthy as whoever last
// wrote to that page.
func sanitizeSVG(svg string) string {
	lower := strings.ToLower(svg)
	for _, bad := range []string{"<script", "</script", "<foreignobject", "javascript:", " onload=", " onclick=", " onerror=", " onmouseover="} {
		if strings.Contains(lower, bad) {
			return ""
		}
	}
	return svg
}

// viewBoxRe reads the only place a stripped SVG still records its real size.
var viewBoxRe = regexp.MustCompile(`viewBox="0 0 ([\d.]+) ([\d.]+)"`)

// diagramStyle sizes a diagram for the page: its own width, capped at the
// column, with the aspect ratio held so nothing is squashed. Returns nothing at
// all when the drawing carries no viewBox — better a default size than a
// mis-stated one.
func diagramStyle(svg string) string {
	m := viewBoxRe.FindStringSubmatch(svg)
	if m == nil {
		return ""
	}
	return ` style="width:min(100%, ` + m[1] + `px);aspect-ratio:` + m[1] + ` / ` + m[2] + `"`
}

// docCSP lets the print view and the shared page run their own script and
// nothing else. The document is rendered from content anybody with write
// access typed, and twice now a way through has turned up in that rendering: a
// diagram's stored SVG with an event handler (1.1.1), and an inline link
// written out as javascript:… (1.1.2). Each was fixed where it happened; this
// makes the next one inert, whatever form it takes. Scripts need the nonce,
// which inline handlers and javascript: addresses can never carry.
func docCSP(w http.ResponseWriter, o *printOptions) {
	b := make([]byte, 16)
	rand.Read(b)
	o.Nonce = base64.RawURLEncoding.EncodeToString(b)
	w.Header().Set("Content-Security-Policy", "script-src 'nonce-"+o.Nonce+"'; object-src 'none'; base-uri 'none'")
}
